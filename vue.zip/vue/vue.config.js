module.exports = {
    devServer: {
        port: 10020  // 前端vue端口号修改
    }
}